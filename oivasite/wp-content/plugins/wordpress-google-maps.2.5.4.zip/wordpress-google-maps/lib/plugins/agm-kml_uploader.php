<?php
/*
Plugin Name: KML Uploader
Description: Allows you to upload your own KML files. <b>Please, make sure you activate the KML Overlay plugin first.</b>
Plugin URI: http://premium.wpmudev.org/project/wordpress-google-maps-plugin
Version: 1.0
Author: Ve Bailovity (Incsub)
*/