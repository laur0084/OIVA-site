<?php
/*
Plugin Name: Fix and Repair
Description: Tools for repairing your Google Maps installation.
Plugin URI: http://premium.wpmudev.org/project/wordpress-google-maps-plugin
Version: 1.0
Author: Ve Bailovity (Incsub)
*/