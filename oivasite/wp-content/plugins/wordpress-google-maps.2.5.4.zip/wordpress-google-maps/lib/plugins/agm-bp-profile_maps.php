<?php
/*
Plugin Name: BuddyPress profile maps
Description: Automatically creates a Map for BuddyPress profiles from a profile address field (if you don't already have such a field, you will have to create one). <br /><b>Requires BuddyPress with extended profiles enabled</b>.
Plugin URI: http://premium.wpmudev.org/project/wordpress-google-maps-plugin
Version: 1.0
Author: Ve Bailovity (Incsub)
*/